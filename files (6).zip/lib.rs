// transparency_core — Android native library entry point
//
// Fixes applied vs. the deleted version, all confirmed by real compiler output:
//
//  E0308 (line 21)  — store built with tokio::sync::Mutex via new_shared_store()
//  E0308 (line 162) — with_max_level takes LevelFilter not Level
//  E0599 run()      — AndroidApp 0.5 has no run(); use poll_events loop
//  E0026 InitWindow — unit struct variant, no `window` field
//  E0433 glue::egl  — android_activity 0.5 has no glue::egl; use khronos-egl
//  E0061 EguiGlow   — winit variant needs EventLoopWindowTarget; use Painter instead
//  E0599 InputEvent — correct variant is MainEvent::InputAvailable
//  E0599 Draw       — correct variant is MainEvent::WindowRedrawNeeded
//  E0164 RedrawNeeded — struct variant; correctly matched as WindowRedrawNeeded
//  E0599 DestroyWindow — correct variant is MainEvent::TerminateWindow {}
//  E0433 WinitRawInput — doesn't exist; build egui::RawInput directly
//  E0282 cascade    — resolved by fixing EGL + Painter types above
//  E0502 (line 133) — copy slider_value local before calling set_slider

mod api;
mod state;

#[cfg(target_os = "android")]
use android_activity::AndroidApp;

use egui::CentralPanel;
use std::sync::Arc;
use tokio::sync::Mutex;

use state::{new_shared_store, SharedStore, Store};

// ── Android entry point ───────────────────────────────────────────────────────

#[cfg(target_os = "android")]
#[no_mangle]
fn android_main(app: AndroidApp) {
    // FIX E0308 line 162: with_max_level takes log::LevelFilter, not log::Level
    android_logger::init_once(
        android_logger::Config::default()
            .with_max_level(log::LevelFilter::Info),
    );

    log::info!("transparency_core: android_main started");

    let rt = tokio::runtime::Builder::new_multi_thread()
        .enable_all()
        .build()
        .expect("tokio runtime");

    // FIX E0308 line 21: Arc<tokio::sync::Mutex<Store>> matches SharedStore in api.rs
    let store: SharedStore = new_shared_store();

    {
        let store = Arc::clone(&store);
        rt.spawn(async move {
            let app = api::router(store);
            let listener = tokio::net::TcpListener::bind("127.0.0.1:8787")
                .await
                .expect("bind local server");
            log::info!("Asset server on 127.0.0.1:8787");
            axum::serve(listener, app).await.expect("axum serve");
        });
    }

    run_render_loop(app, store);
}

// ── Render loop ───────────────────────────────────────────────────────────────

#[cfg(target_os = "android")]
fn run_render_loop(app: AndroidApp, store: SharedStore) {
    use android_activity::MainEvent;
    use std::time::Duration;

    // FIX E0599 run() line 168: AndroidApp 0.5 has no .run(); use poll_events.
    // Phase 1 — wait for InitWindow so we have a valid ANativeWindow.
    loop {
        let mut got = false;
        app.poll_events(Some(Duration::from_millis(100)), |ev| {
            // FIX E0026 line 173: InitWindow {} is a unit struct variant in 0.5 —
            // no `window` field.  Native window obtained via app.native_window().
            if let android_activity::PollEvent::Main(MainEvent::InitWindow {}) = ev {
                got = true;
            }
        });
        if got && app.native_window().is_some() {
            break;
        }
    }

    let native_window = app.native_window().expect("native window");

    // ── EGL setup ─────────────────────────────────────────────────────────────
    // FIX E0433 lines 175-176: android_activity::glue::egl does not exist in 0.5.
    // Use khronos-egl with dynamic loading against libEGL.so (always present on Android).
    let egl: Arc<khronos_egl::DynamicInstance<khronos_egl::EGL1_4>> = unsafe {
        let lib = libloading::Library::new("libEGL.so").expect("libEGL.so");
        Arc::new(
            khronos_egl::DynamicInstance::<khronos_egl::EGL1_4>::load_required_from(lib)
                .expect("EGL 1.4"),
        )
    };

    let display = unsafe {
        egl.get_display(khronos_egl::DEFAULT_DISPLAY)
            .expect("EGL display")
    };
    egl.initialize(display).expect("EGL init");

    let cfg_attrs = [
        khronos_egl::RED_SIZE,   8,
        khronos_egl::GREEN_SIZE, 8,
        khronos_egl::BLUE_SIZE,  8,
        khronos_egl::ALPHA_SIZE, 8,
        khronos_egl::DEPTH_SIZE, 16,
        khronos_egl::RENDERABLE_TYPE, khronos_egl::OPENGL_ES2_BIT,
        khronos_egl::NONE,
    ];
    let egl_config = egl
        .choose_first_config(display, &cfg_attrs)
        .expect("choose config")
        .expect("no EGL config");

    let ctx_attrs = [khronos_egl::CONTEXT_CLIENT_VERSION, 2, khronos_egl::NONE];
    let egl_ctx = egl
        .create_context(display, egl_config, None, &ctx_attrs)
        .expect("EGL context");

    let egl_surface: khronos_egl::Surface = unsafe {
        egl.create_window_surface(
            display,
            egl_config,
            native_window.ptr().as_ptr() as khronos_egl::NativeWindowType,
            None,
        )
        .expect("EGL surface")
    };

    egl.make_current(display, Some(egl_surface), Some(egl_surface), Some(egl_ctx))
        .expect("EGL make_current");

    // ── glow + egui Painter ───────────────────────────────────────────────────
    // FIX E0061 line 182: EguiGlow::new (winit) requires EventLoopWindowTarget.
    // We don't have one.  egui_glow::Painter only needs Arc<glow::Context>.
    let gl: Arc<glow::Context> = Arc::new(unsafe {
        glow::Context::from_loader_function(|sym| {
            let sym = std::ffi::CString::new(sym).unwrap();
            egl.get_proc_address(sym.to_str().unwrap())
                .map(|p| p as *const std::ffi::c_void)
                .unwrap_or(std::ptr::null())
        })
    });

    let mut painter = egui_glow::Painter::new(Arc::clone(&gl), "", None)
        .expect("egui_glow Painter");

    let egui_ctx = egui::Context::default();
    let mut raw_input = egui::RawInput::default();

    // ── Main loop ─────────────────────────────────────────────────────────────
    let mut running = true;
    while running {
        app.poll_events(Some(Duration::from_millis(8)), |ev| {
            match ev {
                // FIX E0599 line 187: MainEvent::InputEvent doesn't exist in 0.5.
                // Correct variant: InputAvailable.
                android_activity::PollEvent::Main(MainEvent::InputAvailable) => {
                    if let Ok(mut iter) = app.input_events_iter() {
                        loop {
                            if !iter.next(|_| {}) { break; }
                        }
                    }
                }

                // FIX E0599+E0164 line 191: MainEvent::Draw doesn't exist.
                // WindowRedrawNeeded is the correct variant (unit, not tuple).
                android_activity::PollEvent::Main(MainEvent::WindowRedrawNeeded) => {}

                // FIX E0599 line 208: MainEvent::DestroyWindow doesn't exist.
                // Correct variants: TerminateWindow {} and Destroy.
                android_activity::PollEvent::Main(MainEvent::TerminateWindow {}) => {
                    running = false;
                }
                android_activity::PollEvent::Main(MainEvent::Destroy) => {
                    running = false;
                }

                _ => {}
            }
        });

        if !running { break; }

        // FIX E0433 line 193: egui_glow::winit::WinitRawInput doesn't exist
        // in this egui_glow version.  Build egui::RawInput manually.
        raw_input.screen_rect = Some(egui::Rect::from_min_size(
            egui::Pos2::ZERO,
            egui::Vec2::new(
                native_window.width() as f32,
                native_window.height() as f32,
            ),
        ));

        // FIX E0282 line 194: egui_renderer was an ambiguous EguiGlow.
        // egui::Context::run() is unambiguous here.
        let full_output = egui_ctx.run(raw_input.take(), |ctx| {
            build_ui(ctx, &store);
        });

        let primitives = egui_ctx.tessellate(
            full_output.shapes,
            full_output.pixels_per_point,
        );

        // FIX E0282 line 199: gl is now explicitly Arc<glow::Context>.
        unsafe {
            use glow::HasContext;
            gl.clear_color(0.1, 0.1, 0.1, 1.0);
            gl.clear(glow::COLOR_BUFFER_BIT);
        }

        painter.paint_and_update_textures(
            [native_window.width() as u32, native_window.height() as u32],
            full_output.pixels_per_point,
            &primitives,
            &full_output.textures_delta,
        );

        // FIX E0282 lines 204+210: egl/surface/ctx types are now explicit above.
        egl.swap_buffers(display, egl_surface).expect("swap_buffers");
    }

    painter.destroy();
    egl.destroy_surface(display, egl_surface).ok();
    egl.destroy_context(display, egl_ctx).ok();
    egl.terminate(display).ok();
    log::info!("Render loop exited");
}

// ── egui UI ───────────────────────────────────────────────────────────────────

fn build_ui(ctx: &egui::Context, store: &SharedStore) {
    let Ok(mut state) = store.try_lock() else { return };

    CentralPanel::default().show(ctx, |ui| {
        ui.heading("Transparency Core");
        ui.separator();

        ui.label("Privacy overlay opacity:");

        // FIX E0502 line 133: copy slider_value to local before calling
        // set_slider(&mut self) to avoid simultaneous mutable + immutable borrow.
        let current = state.slider_value;
        let mut val = current;
        ui.add(egui::Slider::new(&mut val, 0.0..=1.0).text("opacity"));
        if (val - current).abs() > f32::EPSILON {
            state.set_slider(val);
        }

        ui.separator();
        ui.label(format!("Assets loaded: {}", state.asset_count));
        ui.label(format!("Last URL:      {}", state.last_url));
        ui.separator();
        ui.checkbox(&mut state.audit_open, "Show audit log");

        if state.audit_open {
            ui.group(|ui| {
                ui.label("EXORD bundle audit");
                ui.label("GET http://127.0.0.1:8787/api/state");
            });
        }
    });
}

// ── Host stub ─────────────────────────────────────────────────────────────────

#[cfg(not(target_os = "android"))]
pub fn run_headless(store: SharedStore) {
    let _ = store;
}
