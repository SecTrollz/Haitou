use std::sync::Arc;
use tokio::sync::Mutex;

/// Runtime state shared between the HTTP server and the egui render loop.
#[derive(Debug, Clone)]
pub struct Store {
    /// Transparency overlay opacity — 0.0 (hidden) … 1.0 (fully visible).
    /// Field name confirmed by E0502 compiler message: `state.slider_value`.
    pub slider_value: f32,
    /// Whether the privacy audit panel is expanded.
    pub audit_open: bool,
    /// Last URL served by the local asset server.
    pub last_url: String,
    /// Total assets loaded from the EXORD bundle.
    pub asset_count: usize,
}

impl Default for Store {
    fn default() -> Self {
        Store {
            slider_value: 0.5,
            audit_open:   false,
            last_url:     String::new(),
            asset_count:  0,
        }
    }
}

impl Store {
    /// Set the transparency slider value, clamping to [0.0, 1.0].
    pub fn set_slider(&mut self, val: f32) {
        self.slider_value = val.clamp(0.0, 1.0);
    }
}

/// Thread-safe handle — uses tokio::sync::Mutex so it can be held across
/// .await points in the Axum handlers.
pub type SharedStore = Arc<Mutex<Store>>;

pub fn new_shared_store() -> SharedStore {
    Arc::new(Mutex::new(Store::default()))
}

/// Thread-safe handle passed to both the Axum router and the render loop.
pub type SharedStore = Arc<Mutex<Store>>;

pub fn new_shared_store() -> SharedStore {
    Arc::new(Mutex::new(Store::default()))
}
