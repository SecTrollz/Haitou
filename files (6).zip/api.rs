use axum::{
    extract::{Path, State},
    http::{header, StatusCode},
    response::{IntoResponse, Response},
    routing::get,
    Router,
};
use std::sync::Arc;

use crate::state::SharedStore;

/// Application state injected into every Axum handler.
#[derive(Clone)]
pub struct ApiState {
    pub store:      SharedStore,
    pub assets_dir: Arc<std::path::PathBuf>,
}

/// Build the Axum router.  `store` must be `Arc<tokio::sync::Mutex<Store>>`.
pub fn router(store: SharedStore) -> Router {
    let assets_dir = Arc::new(
        std::env::var("EXORD_ASSETS_DIR")
            .map(std::path::PathBuf::from)
            .unwrap_or_else(|_| std::path::PathBuf::from("assets")),
    );

    let state = ApiState { store, assets_dir };

    Router::new()
        .route("/",         get(serve_index))
        .route("/*path",    get(serve_asset))
        .route("/api/state", get(get_state))
        .with_state(state)
}

async fn serve_index(State(s): State<ApiState>) -> impl IntoResponse {
    serve_file(&s.assets_dir, "index.html").await
}

async fn serve_asset(
    State(s): State<ApiState>,
    Path(path): Path<String>,
) -> impl IntoResponse {
    // Update last_url in store (non-blocking: skip if lock is contended)
    if let Ok(mut st) = s.store.try_lock() {
        st.last_url = format!("/{}", path);
    }
    serve_file(&s.assets_dir, &path).await
}

async fn get_state(State(s): State<ApiState>) -> impl IntoResponse {
    let st = s.store.lock().await;
    let body = serde_json::json!({
        "slider_val":  st.slider_val,
        "audit_open":  st.audit_open,
        "last_url":    st.last_url,
        "asset_count": st.asset_count,
    });
    (
        StatusCode::OK,
        [(header::CONTENT_TYPE, "application/json")],
        body.to_string(),
    )
}

// ── helpers ──────────────────────────────────────────────────────────────────

async fn serve_file(assets_dir: &std::path::Path, rel_path: &str) -> Response {
    let full_path = assets_dir.join(rel_path.trim_start_matches('/'));

    match tokio::fs::read(&full_path).await {
        Ok(bytes) => {
            let mime = mime_for_path(rel_path);
            (
                StatusCode::OK,
                [(header::CONTENT_TYPE, mime)],
                bytes,
            )
                .into_response()
        }
        Err(_) => {
            // SPA fallback: serve index.html for unknown paths
            match tokio::fs::read(assets_dir.join("index.html")).await {
                Ok(bytes) => (
                    StatusCode::OK,
                    [(header::CONTENT_TYPE, "text/html; charset=utf-8")],
                    bytes,
                )
                    .into_response(),
                Err(_) => (StatusCode::NOT_FOUND, "Not found").into_response(),
            }
        }
    }
}

fn mime_for_path(path: &str) -> &'static str {
    let ext = path.rsplit('.').next().unwrap_or("").to_lowercase();
    match ext.as_str() {
        "html" | "htm"  => "text/html; charset=utf-8",
        "js"   | "mjs"  => "application/javascript; charset=utf-8",
        "css"           => "text/css; charset=utf-8",
        "json"          => "application/json; charset=utf-8",
        "svg"           => "image/svg+xml",
        "png"           => "image/png",
        "jpg" | "jpeg"  => "image/jpeg",
        "gif"           => "image/gif",
        "webp"          => "image/webp",
        "ico"           => "image/x-icon",
        "woff"          => "font/woff",
        "woff2"         => "font/woff2",
        "ttf"           => "font/ttf",
        "mp4"           => "video/mp4",
        "webm"          => "video/webm",
        _               => "application/octet-stream",
    }
}
